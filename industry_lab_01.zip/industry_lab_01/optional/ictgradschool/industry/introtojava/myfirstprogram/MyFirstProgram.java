package ictgradschool.industry.introtojava.myfirstprogram;

public class MyFirstProgram {
    public void start() {
        System.out.println("Hello World");
    }
    
    public static void main(String[] args) {
        MyFirstProgram p = new MyFirstProgram();
        p.start();
    }
}

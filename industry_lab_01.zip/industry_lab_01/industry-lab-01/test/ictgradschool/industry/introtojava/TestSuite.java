package ictgradschool.industry.introtojava;

import ictgradschool.industry.introtojava.simplemaths.TestSimpleMaths;
import org.junit.runners.Suite;

@Suite.SuiteClasses({
        TestSimpleMaths.class,
})
public class TestSuite { }

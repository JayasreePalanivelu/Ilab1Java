package ictgradschool.industry.introtojava.examples;

/*
 * This is a simple Java program.
 * Name this file "MyFirstProgram.java".
 */
public class MyFirstProgram {
    public void start() {
        System.out.println("Hello World");
    }

    // All Java programs begin with the method: main().
    public static void main(String[] args) {
        MyFirstProgram p = new MyFirstProgram();
        p.start();
    }
}
